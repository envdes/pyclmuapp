# encoding: utf-8
# Author: Junjie Yu, 2024-5-18
# Description: CLI for pyclmuapp

import pyclmuapp._cli as _cli

if __name__ == "__main__":
    _cli.main()
