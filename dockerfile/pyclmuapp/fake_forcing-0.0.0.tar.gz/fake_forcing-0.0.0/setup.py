from setuptools import setup, find_packages, Extension
import os

classifiers = [
    "Development Status :: 1 - Pre-Alpha",
    "Intended Audience :: Science/Research",
    "License :: OSI Approved :: MIT License",
    "Natural Language :: English",
    "Operating System :: OS Independent",
    "Programming Language :: Python :: 3",
    "Topic :: Scientific/Engineering :: Earth and Environmental Sciences"
    ]

with open("README.md", "r") as fp:
    long_description = fp.read()

setup(
    name="fake_forcing",
    version="0.0.0",
    author="Junjie Yu",
    author_email="yjj1997@live.cn",
    url="https://github.com/JunjieYU-UoM/clmu_fake_forcing",
    description="Generate fake forcing data for CLMU",
    long_description=long_description,
    license="MIT",
    classifiers=classifiers,
    install_requires=['numpy', 'pandas', 'xarray', 'haversine', 'netcdf4', 'nc-time-axis', 'gradio'],
    packages=find_packages(),
    package_data={'fake_forcing': ['distribution.csv']},
    )