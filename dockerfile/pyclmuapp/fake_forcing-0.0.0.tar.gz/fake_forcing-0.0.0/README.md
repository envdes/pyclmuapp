# CLMU_fake_forcing
 Generate fake forcing based on historical data.
