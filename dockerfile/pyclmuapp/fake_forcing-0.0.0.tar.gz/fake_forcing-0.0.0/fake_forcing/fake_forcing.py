import numpy as np
import pandas as pd
import xarray as xr
from typing import Union
from datetime import datetime
import os

forcing_vars = ['SWdown', 'LWdown', 'Qair', 'Tair', 'Wind', 'Prectmms', 'PSurf']
dist = pd.read_csv(os.path.join(os.path.dirname(__file__), 'distribution.csv'))

def fake_forcing(dist: Union[pd.DataFrame, str],
                 month: int,
                 var: str) -> np.array:
    
    """ 
    
    Generate fake forcing data for a given month and variable
    
    Args:
        dist (pd.DataFrame, str): distribution of the forcing data (mean, std, max, min, hour_minute, month, var)
        month (int): month
        var (str): variable name

    Returns:
        np.array: fake forcing data
    """
    
    if isinstance(dist, str):
        dist = pd.read_csv(dist)
    
    mean = dist[(dist['month'] == month) & (dist['var'] == var)]['mean'].values
    std = dist[(dist['month'] == month) & (dist['var'] == var)]['std'].values
    max_ = dist[(dist['month'] == month) & (dist['var'] == var)]['max'].values
    min_ = dist[(dist['month'] == month) & (dist['var'] == var)]['min'].values
    data = np.random.normal(mean, std)
    # clip the data to the min and max values
    data = data.clip(min_, max_)
    return data


def get_fake_forcing_nc(dist : Union[pd.DataFrame, str],
                        year : int,
                        month : int,
                        day : int,
                        Zbot : float = 30.0,
                        ouput_nc=None):
    
    """
    
    Generate fake forcing data for a given year, month, and day
    
    Args:
    
        dist (pd.DataFrame, str): distribution of the forcing data (mean, std, max, min, hour_minute, month, var)
        year (int): year
        month (int): month
        day (int): day
        zbot (float): observation height, m
        ouput_nc (str): output netcdf file, if None, the function will not save the file
    
    Returns:
        
        xr.Dataset: fake forcing data
        
    """
    
    if isinstance(dist, str):
        dist = pd.read_csv(dist)
    
    forcing_vars = ['SWdown', 'LWdown', 'Qair', 'Tair', 'Wind', 'Prectmms', 'PSurf']
    time_values = pd.to_datetime(f'{year}-{month:02d}-{day:02d} ' + dist[(dist['month'] == month) & (dist['var'] == 'Tair')]['hour_minute'].values)
    data = {
            "coords": {
        "time": {"dims": "time", "data": time_values, "attrs": {"standard_name": "time"}},
    },
    "dims": "t",
    "data_vars": {
    },
    }
    
    data_vars = {var: fake_forcing(dist, month, var) for var in forcing_vars}
    
    for var in forcing_vars:
        data['data_vars'][var] = {"dims": ("time"), "data": data_vars[var]}
    
    forcing = xr.Dataset.from_dict(data)
    forcing['x'] = 1
    forcing['y'] = 1
    forcing = forcing.assign_coords(x=1,y=1)
    for var in forcing.data_vars:
        forcing[var] = forcing[var].expand_dims('x',axis=1).expand_dims('y',axis=1)
    
    forcing['Zbot'] = forcing[var] * 0 + Zbot
    if ouput_nc and isinstance(ouput_nc, str):
        forcing.to_netcdf(ouput_nc)
    return forcing

def get_time(time):
    """
    Get the time in datetime format
    Args:
        time: str, time in the format of 'YYYY-MM-DD'

    Returns:
        datetime: datetime object
    """
    return datetime.strptime(time, '%Y-%m-%d')
    #return datetime.timestamp(time)

def get_fake_forcing_ncs(dist: Union[pd.DataFrame, str],
            RUN_STARTDATE : str,
            STOP_OPTION : str,
            STOP_N : int,
            Zbot : float = 30.0,
            ouput_nc=None):

    """
    
    Get the forcing data for a given period

    Args:

        dist (pd.DataFrame, str): distribution of the forcing data (mean, std, max, min, hour_minute, month, var)
        RUN_STARTDATE (str): start date in the format of 'YYYY-MM-DD'
        STOP_OPTION (str): stop option, 'ndays', 'nmonths', or 'nyears'
        STOP_N (int): number of days, months, or years
        Zbot (float): observation height, m
        ouput_nc (str): output netcdf file, if None, the function will not save the file
        
    """
    
    if isinstance(dist, str):
        dist = pd.read_csv(dist)

    if STOP_OPTION == "ndays":
        dateparam = {'days': STOP_N}
    elif STOP_OPTION == "nmonths":
        dateparam = {'months': STOP_N}
    elif STOP_OPTION == "nyears":
        dateparam = {'years': STOP_N}
    else:
        raise ValueError("The STOP_N is not correct. please use 'ndays', 'nmonths', or 'nyears'.")

    START = get_time(RUN_STARTDATE)
    END = START + pd.DateOffset(**dateparam)

    forcing = []
    while not START > END:
        year = pd.to_datetime(START).year
        month = pd.to_datetime(START).month
        day = pd.to_datetime(START).day
        forcing_ = get_fake_forcing_nc(dist, year, month, day, Zbot)
        forcing.append(forcing_)
        START = START + pd.DateOffset(days=1)

    forcing = xr.concat(forcing, dim='time')
    if ouput_nc and isinstance(ouput_nc, str):
        forcing.to_netcdf(ouput_nc)
    return forcing


def future_scenario(dist: Union[pd.DataFrame, str],
                    RUN_STARTDATE : str,
                    STOP_OPTION : str,
                    STOP_N : int,
                    FUTURE_VAR : dict,
                    Zbot : float = 30.0,
                    ouput_nc=None):

    """
    
    Get the forcing data for a given period

    Args:

        dist (pd.DataFrame, str): distribution of the forcing data (mean, std, max, min, hour_minute, month, var)
        RUN_STARTDATE (str): start date in the format of 'YYYY-MM-DD'
        STOP_OPTION (str): stop option, 'ndays', 'nmonths', or 'nyears'
        STOP_N (int): number of days, months, or years
        Zbot (float): observation height, m
        ouput_nc (str): output netcdf file, if None, the function will not save the file
        
    """
    
    if isinstance(dist, str):
        dist = pd.read_csv(dist)


    for var in FUTURE_VAR:
        if var not in dist['var'].unique():
            raise ValueError(f"The variable {var} is not in the distribution file.")
        else:
            dist.loc[dist['var'] == var, 'mean'] += FUTURE_VAR[var]
            dist.loc[dist['var'] == var, 'max'] += FUTURE_VAR[var]


    if STOP_OPTION == "ndays":
        dateparam = {'days': STOP_N}
    elif STOP_OPTION == "nmonths":
        dateparam = {'months': STOP_N}
    elif STOP_OPTION == "nyears":
        dateparam = {'years': STOP_N}
    else:
        raise ValueError("The STOP_N is not correct. please use 'ndays', 'nmonths', or 'nyears'.")

    START = get_time(RUN_STARTDATE)
    END = START + pd.DateOffset(**dateparam)

    forcing = []
    while not START > END:
        year = pd.to_datetime(START).year
        month = pd.to_datetime(START).month
        day = pd.to_datetime(START).day
        forcing_ = get_fake_forcing_nc(dist, year, month, day, Zbot)
        forcing.append(forcing_)
        START = START + pd.DateOffset(days=1)

    forcing = xr.concat(forcing, dim='time')
    if ouput_nc and isinstance(ouput_nc, str):
        forcing.to_netcdf(ouput_nc)
    return forcing