# Junjie Yu, 2024-05-25

from fake_forcing.fake_forcing import *

__version__ = '0.0.0'

__annotations__ = {
    'fake_forcing': fake_forcing.__annotations__,
    'get_fake_forcing_nc': get_fake_forcing_nc.__annotations__
}
